﻿#include <iostream>
#include <iostream>
#include <windows.h>
#include <chrono>



using namespace std;
using namespace std::chrono;


//function prototypes

void petname(int*,int*,int*,int*, int*,string*);
void mainmenu(int*, int*, int*, int*, int*, int*, string*);
void feed_pet(int*, int*, int*, int*, int*, string*);
void sleep_pet(int*, int*, int*, int*,int*,  string*);
void Pet_status(int*, int*, int*, int*, int*, string*);
void happinesslevel(int*, int*, int*,int*,int*,int*, string*);
int gameover(int*, int*,int*, int*, int*, int*, string*);

int main()


{
	system("Color 1b");												// this sets the colour of the background and the text to the chosen colour red background and aqua blue text


	// variable names

	string pet_name = "";
	int hungerlevel = 2;
	int sleeplevel = 2 ;										
	int happiness_level = (sleeplevel + hungerlevel)/2;				// this is how i used the value of hunger and sleepiness to creat an average to indicate happiness so they can be 2 different values 
	int petstatus = 2;
	int inputs = 0;

																		

	string* name = &pet_name;
	int* hunger = &hungerlevel;
	int* sleep = &sleeplevel;
	int* statushunger = &petstatus;								// these pointers are converting the address with the value i have chosen for each variable above using the & this will allow me to use them throughout my program by just dereferencing them using *
	int* statussleep = &petstatus;
	int* happiness = &happiness_level;
	
	int* input = &inputs;



	// only 2 function calls used in my int main 

	petname(hunger,sleep,statushunger,statussleep,happiness,name);
	mainmenu(hunger, sleep, statushunger, statussleep, happiness,input, name);
	
}

// this function will be called first to allow the player to name there pet, the name they enter will be stored as a value and used as reference throughout program. The user can also select a default name

void petname(int* hunger, int* sleep, int* statushunger, int* statussleep, int* happiness,string* name)
 
 {
// reset the values of hunger and sleep to initial value when game restarts 
	*hunger = 2;
	*sleep = 2;
	*happiness = (*hunger + *happiness) /2;

	cout << "       ((`\ " << endl;
	cout << "     ___ \\ '--._" << endl;
	cout << "  .'`   `'    o  )" << endl;
	cout << " /    \   '. __.'" << endl;
	cout << "_|    /_  \ \_\_" << endl;
	cout << " {_\______\-'\__\_\ " << endl;
	


;
 	cout << "			Congratulations!! you have a new pet what would you like to call him?? " << endl;
	cout << "" << endl;
	cout << "" << endl;
 	cout << "		if you dont want to name your pet just press F and we will call your friend Your Pet " << endl;
	cin >> *name;

	if (*name ==  "F" || *name == "f")				// this covers the basis that the user enters a lower or upper case character

	{
		*name = "Your Pet";							// this will be the default name if the user selects F
	}

}

void mainmenu(int* hunger, int* sleep, int*statushunger, int* statussleep, int*happiness, int *input, string* name)
{
	steady_clock::time_point time_point1 = steady_clock::now(); // timepoint
	
	do
	{																								
		steady_clock::time_point time_point2 = steady_clock::now(); // timepoint 2
		duration<double> time_span = duration_cast<duration<double>>(time_point2 - time_point1); // difference 

		// Above i have created an initial timepoint using chrono outside the loop. and then inside the loop another time point the timespan variable will 
		// continuously check the time between the first static timepoint and the second and store the duration inbetween as a variable



		if (time_span.count() >= 10 && time_span.count() <= 10.5)    //  every 10 seconds the pets hunger and sleep levels will depreciate by 1 
		{
			*hunger = *hunger - 1;
			*sleep = *sleep - 1;

		}
		if (time_span.count() >= 11)								// after 11 seconds the counter will reset and call the main menu function to start the timer from the top 
																	// this will ensure the hunger and sleep depriciates continuosly in the background
		{

			time_span = std::chrono::milliseconds::zero();
	
			// this is the second function call after the pet has been named and will carry over the chosen name as it has been dereferenced using * as shown below

			mainmenu(hunger, sleep, statushunger, statussleep, happiness, input, name);
		}


		cout << "" << endl;
		cout << "					---------------------------------------------------------------------------" << endl; 
		cout << "					Please select an option from the menu below : " << endl;
		cout << "" << endl;
		cout << "					please press [1] to feed " << *name << endl; 
		cout << "" << endl;
		cout << "					please press [2] to put " << *name << " to sleep " << endl; 
		cout << "" << endl;
		cout << "					press [3] to display " << *name << ("s") << " status"  << endl;
		cout << "" << endl;
		cout << "					press [4] to stop playing with " << *name << endl;
		cout << "" << endl;
		cout << "					press [5] to see " << *name << "s" << " happiness level" << endl;
		cout << "					--------------------------------------------------------------------------" << endl;		
		cin >> *input; 


		// this switch statement is what i am using for menu selection each number corresponds a function call except 4 which will terminate the program

		switch (*input)
		{
		case 1:feed_pet(hunger, sleep, happiness, statussleep,statushunger, name);


			break;

		case 2:sleep_pet(sleep, hunger, happiness, statussleep,statushunger, name);

			break;

		case 3:Pet_status(hunger, sleep, statushunger,statussleep,happiness,name);

			break;

		case 4: cout << " thank you for playing we hope to see you again " << endl;
			exit(1);

			break;

		case 5: happinesslevel(happiness,hunger,sleep,statushunger,statussleep,input,name);

			break;
		}

		
		// this will close the program if an invalid choice is made and stop an infinite loop from occuring as im using a switch inside a do while
		if (*input != 1 && *input != 2 && *input != 3 && *input != 4 && *input != 5)

		{
			cout << "" << endl;
			cout << " the game will close as you have entered an invalid choice " << endl;
			cout << "" << endl;

			break;
		}

		} while (*input != 4);
}

// this function is used to feed the pet. when the user selects 1 to feed the pet it increases by 1 each time 
// if the pet is full it will tell the user and if the hunger falls to 0 the pet will die and direct user to gameober function

void feed_pet(int* hunger, int* sleep, int* happiness, int* statussleep, int* statushunger, string* name)

{

	if (*hunger != 4)
	{

		*hunger = *hunger + 1;
		
		cout << "********************************************************************************************" << endl;
		cout << "" << endl;
		cout << "" << endl;
		cout << *name << " is now eating " << endl;
		cout << "" << endl;
		cout << "" << endl;
		cout << "********************************************************************************************" << endl;
	}
	else
	{
		cout << "********************************************************************************************" << endl;
		cout << "" << endl;
		cout << "" << endl;
		cout << *name << " is full " << endl;
		cout << "" << endl;
		cout << "" << endl;
		cout << "********************************************************************************************" << endl;
	}

	if (*hunger == 0)
	{
		gameover(hunger, sleep, happiness, statussleep,statushunger,happiness,name);

	}
	}


// the same method as above however as the pet sleeps the hunger level decreases it also gives a warning message when the hunger level drops to 1 giving the user time to feed pet
// if the pet dies then it returns the user to the game over function


void sleep_pet(int* sleep,int* hunger,int* happiness, int* statussleep, int* statushunger, string* name)

 {

	if (*sleep != 4)

	 {
		 *sleep = *sleep + 1;
		 *hunger = *hunger - 1;

		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << *name << "	is now sleeping " << endl;
		 cout << "" << endl;
		 cout << *name <<  " is feeling a little more hungry "  << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;
	}
	 else
	 {
		cout << "********************************************************************************************" << endl;
		cout << "" << endl;
		cout << "" << endl;
		 cout << *name << "	is not needing anymore sleep " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;
	 }

	if (*hunger == 1)
	
		cout << " your pet is about to die with hunger FEED " << *name << " quickly" << endl;

	else if(hunger ==0)

		gameover(hunger, sleep, happiness, statussleep,statushunger, happiness, name);

}


// i have used 2 switch statements here so both hunger and sleep can be measuered as a value and display it to the user using the 3 input
// if the users sleep and hunger levels are 0 then it will direct user to game over function 

 void Pet_status( int* statushunger,int*statussleep, int* hunger, int* sleep, int* happiness,string* name)

{
	 switch (*statushunger)
	 {

	 case 0: *hunger = 0;
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << *name << " is Dead " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;
		 break;

	 case 1: *hunger = 1;
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << *name << "	is starving " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;

		 break;

	 case 2: *hunger = 2;
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << *name << "	is Rather Hungry  " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;

		 break;

	 case 3: *hunger = 3;
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << *name << "	is Slightly Peckish " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;

		 break;

	 case 4:  *hunger = 4;
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << *name << "	is Well Fed " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;

		 break;

	 }


	switch (*statussleep)

		 {
		 case 0: *sleep = 0;
			 cout << "********************************************************************************************" << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << *name << " is Unconcious " << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << "********************************************************************************************" << endl;

			 break;

		 case 1: *sleep = 1;
			 cout << "********************************************************************************************" << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << *name << " is Falling Asleep " << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << "********************************************************************************************" << endl;

			 break;

		 case 2: *sleep = 2;
			 cout << "********************************************************************************************" << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << *name << "	is Tired  " << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << "********************************************************************************************" << endl;

			 break;

		 case 3:*sleep = 3;
			 cout << "********************************************************************************************" << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << *name << "	is Awake " << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << "********************************************************************************************" << endl;

			 break;

		 case 4: *sleep = 4;
			 cout << "********************************************************************************************" << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << *name << "	is Wide Awake " << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << "********************************************************************************************" << endl;

			 break;
	}

	if (*sleep == 0 || *hunger == 0)

		gameover(hunger, sleep, happiness, statussleep,statushunger, happiness, name);
}


 // the happiness level is based on the  hunger and sleep levels when the pet is fully fed and awake the pet is most happy
 //  the player uses treats and throws a ball to play with the pet and doing so
 // increases the pets happiness and hunger but depletes sleep, if the user plays with the pet too much it will give a warning before 
 // blowing the pet up and calling the game over function
 //  if the user selects any key apart from P to play it will return to main menu and continue loop 
 // if the sleep depletes to 0 the game over function will be called

 void happinesslevel(int* statushunger, int* statussleep, int* happiness, int* hunger, int* sleep,  int* input, string* name)
 {

	 

	 if (*happiness == 4)

	 {
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << " your pets too in love with you to play right now" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;


	 }

	 else if (*happiness ==3)

	 {
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << " your pet is very happy but could use a little fun" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;


	 }
	 else if (*happiness  ==2)

	 {
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << " your pet is quite happy and is looking for you to throw something " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;


	 }
	 else if (*happiness ==1)
		
	 {
		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << " your pet is depressed and dreaming of a new owner  " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;

	 }



	 if (*happiness != 5)

	 {
		 char play = 'p';

		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << " would you like to play with " << *name << " and give them treats to increase there mood ? if so press P " << endl;
		 cout << "" << endl;
		 cout << " dont over do it though because although you will feed your pet " << endl;
		 cout << " " << endl;
		 cout << "he will also get tired from all the fun!and he will explode " << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << "********************************************************************************************" << endl;
		 cin >> play;




		 if (play == 'p' || play == 'P') 
		 {

			 cout << "********************************************************************************************" << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << " you have thrown a ball for " << *name << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << "********************************************************************************************" << endl;

			 *happiness = *happiness + 1;
			 *sleep = *sleep - 1;
			 *hunger = *hunger + 1;

		 }

		 else

			 mainmenu(hunger, sleep, statushunger, statussleep, happiness, input, name);


		 if (*sleep == 0)
		 {

			 gameover(hunger, sleep, happiness, statussleep, statushunger, input, name);
		 }



		 else if (*happiness == 5)
		 {
			 cout << "********************************************************************************************" << endl;
			 cout << "" << endl;
			 cout << "" << endl;
			 cout << " well done you blew " << *name << " up " << endl;
			 cout << " " << endl;
			 cout << "" << endl;
			 cout << "********************************************************************************************" << endl;

			 gameover(hunger, sleep, happiness, statussleep, statushunger, input, name);

		 }
		 }
		}
	 
	 // the game over function will give the player the option to press C to create a new pet or any other key to exit the program 
	// if the user selects C then the name pet function will be called reseting the pets hunger and sleep levels to that at the beggining of the game
	// if the user presses R once the pet has died they have a chance to revive there pet if they roll a 6 if they roll a 6 the pets hunger and sleep increase by 2 and calls the mainmenu functiom

	 
	 int gameover( int* statussleep, int* statushunger, int* happiness, int* sleep, int* hunger,int*input, string* name)

	 {
		 char choice = 'C';

		 cout << "********************************************************************************************" << endl;
		 cout << "" << endl;
		 cout << "" << endl;
		 cout << *name << " has died " << " we hope you look after your next pet a little better " << endl;
		 cout << "" << endl;
		 cout << " please press C to start a new Game or any other key to quit  "<< endl;
		 cout << "" << endl;
		cout << "" << endl;
		cout << "********************************************************************************************" << endl;
		cin >> choice;

		if (choice == 'C' || choice == 'c')



		{	//resets the values to original at beggining of game
			*hunger = 2;
			*sleep = 2;
			*happiness = (*hunger + *sleep) / 2;

			petname( hunger, sleep,statushunger,statussleep, happiness ,name);

			
		}

			 else
			 exit(1);

		return 0;
		
	 }
 










 
 






